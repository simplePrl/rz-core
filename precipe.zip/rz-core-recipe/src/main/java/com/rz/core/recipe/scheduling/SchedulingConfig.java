package com.rz.core.recipe.scheduling;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

@Configuration
@ImportResource("scheduling-bean.xml")
public class SchedulingConfig {

}
