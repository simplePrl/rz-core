package com.rz.core.recipe.scheduling;

public class Constant {
    public static final String SEPARATOR = "/";
    public static final String MONOPOLY = "monoply";
    public static final String QUEUE_NODE = "queue-node";
}
