package com.rz.core.recipe.scheduling;

public class Tester {
    public void test() {
        System.out.println("test");
    }
}
